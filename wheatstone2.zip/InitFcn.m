% computation values are the nominal component
% and voltage values: R_NOM and V1_NOM
R_NOM = 1000;
V1_NOM = 1;
% The actual simulation values are R, R4_DUT, and V1
% which include an optional error component RGE and 
% V1GE which are currently gain type errors
R4_DUT = 1000;
RGE = -1*0.05; % resistor gain error
V1GE = 1*0.05; % V1 source voltage error
ME = 0*0.02; % measurement gain error
R = R_NOM*(1+RGE);
V1 = V1_NOM*(1+V1GE)



